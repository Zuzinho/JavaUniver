package practice.student;

public class StudentView {
    public void printStudentDetails(String rollNo,String name){
        System.out.printf("Student:\nrollNo: %1$s\nname: %2$s\n",rollNo,name);
    }
}
