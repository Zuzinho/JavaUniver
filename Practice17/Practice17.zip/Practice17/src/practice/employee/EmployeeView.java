package practice.employee;

public class EmployeeView {
    public void printEmployeeDetails(String name,int salary){
        System.out.printf("Employee:\nName: %1$s\nSalary: %2$s\n",name,salary);
    }
}
